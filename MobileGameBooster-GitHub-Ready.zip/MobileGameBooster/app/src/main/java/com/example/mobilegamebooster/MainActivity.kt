package com.example.mobilegamebooster

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.DecimalFormat
import kotlin.math.max

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 17, 22)
    private val panel = Color.rgb(27, 29, 37)
    private val accent = Color.rgb(119, 133, 255)
    private val muted = Color.rgb(160, 164, 180)
    private val prefs: SharedPreferences by lazy {
        getSharedPreferences("booster_profiles", Context.MODE_PRIVATE)
    }
    private lateinit var content: LinearLayout
    private lateinit var ramValue: TextView
    private lateinit var batteryValue: TextView
    private lateinit var storageValue: TextView
    private lateinit var tempValue: TextView
    private val df = DecimalFormat("0.0")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
        refreshStats()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(label("MOBILE GAME", 12, muted, true))
        titleBox.addView(label("BOOSTER", 27, Color.WHITE, true))
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("ANDROID  •  ${Build.VERSION.SDK_INT}", 11, muted, true))
        content.addView(header)
        content.addView(space(20))

        content.addView(sectionTitle("VISÃO GERAL"))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = horizontal()
        ramValue = statCard("RAM DISPONÍVEL", "—", row1)
        batteryValue = statCard("BATERIA", "—", row1)
        val row2 = horizontal()
        storageValue = statCard("ARMAZENAMENTO", "—", row2)
        tempValue = statCard("TEMPERATURA", "—", row2)
        stats.addView(row1)
        stats.addView(space(10))
        stats.addView(row2)
        content.addView(stats)
        content.addView(space(22))

        content.addView(sectionTitle("PERFIL DE DESEMPENHO"))
        val profileGroup = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = rounded(panel, 16)
        }
        val profiles = listOf(
            "Econômico" to "Reduz consumo e prioriza autonomia.",
            "Equilibrado" to "Boa opção para uso diário e jogos.",
            "Desempenho" to "Prioriza recursos disponíveis para o jogo."
        )
        val saved = prefs.getString("profile", "Equilibrado") ?: "Equilibrado"
        profiles.forEach { (name, description) ->
            val item = RadioButton(this).apply {
                text = "$name\n$description"
                textSize = 14f
                setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                setPadding(dp(4), dp(8), dp(4), dp(8))
                isChecked = name == saved
                setOnClickListener { prefs.edit().putString("profile", name).apply() }
            }
            profileGroup.addView(item)
        }
        content.addView(profileGroup)
        content.addView(space(10))
        content.addView(actionButton("ATUALIZAR INDICADORES") { refreshStats() })
        content.addView(space(22))

        content.addView(sectionTitle("SEUS JOGOS"))
        content.addView(label("Aplicativos com atalho de inicialização detectado pelo Android.", 12, muted))
        content.addView(space(8))
        val games = findLaunchableApps()
        if (games.isEmpty()) {
            content.addView(label("Nenhum aplicativo encontrado.", 14, muted))
        } else {
            games.take(40).forEach { app ->
                val item = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    background = rounded(panel, 12)
                }
                val name = TextView(this).apply {
                    text = app.loadLabel(packageManager).toString()
                    textSize = 14f
                    setTextColor(Color.WHITE)
                    maxLines = 1
                }
                item.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
                val open = TextView(this).apply {
                    text = "ABRIR"
                    textSize = 11f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(accent)
                    setPadding(dp(12), dp(8), dp(4), dp(8))
                    setOnClickListener {
                        val launch = packageManager.getLaunchIntentForPackage(app.packageName)
                        if (launch != null) startActivity(launch)
                        else toast("Não foi possível abrir este aplicativo.")
                    }
                }
                item.addView(open)
                content.addView(item)
                content.addView(space(6))
            }
        }
        content.addView(space(18))

        content.addView(sectionTitle("ATALHOS DO ANDROID"))
        content.addView(actionButton("CONFIGURAÇÕES DE BATERIA") {
            openSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        })
        content.addView(space(8))
        content.addView(actionButton("CONFIGURAÇÕES DE ARMAZENAMENTO") {
            openSettings(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
        })
        content.addView(space(8))
        content.addView(actionButton("CONFIGURAÇÕES DE TELA") {
            openSettings(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        })
        content.addView(space(18))
        content.addView(label(
            "Otimização honesta: o Android controla CPU, GPU e processos em segundo plano. " +
            "Este app não força overclock, não encerra processos de outros apps e não promete FPS artificial.",
            11, muted
        ))
        setContentView(root)
    }

    private fun refreshStats() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memory)
        ramValue.text = "${df.format(memory.availMem / 1073741824.0)} GB"

        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        batteryValue.text = if (level >= 0 && scale > 0) "${(level * 100) / scale}%" else "Indisponível"

        val temp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        tempValue.text = if (temp > 0) "${df.format(temp / 10.0)} °C" else "Indisponível"

        try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val free = stat.availableBytes / 1073741824.0
            val total = stat.totalBytes / 1073741824.0
            storageValue.text = "${df.format(free)} / ${df.format(total)} GB"
        } catch (_: Exception) {
            storageValue.text = "Indisponível"
        }
        toast("Indicadores atualizados")
    }

    private fun findLaunchableApps(): List<android.content.pm.ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val results = if (Build.VERSION.SDK_INT >= 33) {
            packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(intent, 0)
        }
        return results.sortedBy { it.loadLabel(packageManager).toString().lowercase() }
            .filter { it.activityInfo.packageName != packageName }
    }

    private fun statCard(title: String, initial: String, row: LinearLayout): TextView {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(10), dp(14))
            background = rounded(panel, 14)
        }
        card.addView(label(title, 10, muted, true))
        val value = label(initial, 21, Color.WHITE, true)
        card.addView(value)
        row.addView(card, LinearLayout.LayoutParams(0, dp(82), 1f).apply {
            if (row.childCount > 0) marginStart = dp(8)
        })
        return value
    }

    private fun horizontal() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun sectionTitle(s: String) = label(s, 12, accent, true).apply {
        setPadding(0, 0, 0, dp(10))
    }
    private fun label(s: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
    private fun actionButton(text: String, action: () -> Unit) =
        TextView(this).apply {
            this.text = text
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(15), dp(14), dp(15))
            background = rounded(Color.rgb(39, 42, 54), 12)
            setOnClickListener { action() }
        }
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }
    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun openSettings(intent: Intent) {
        try { startActivity(intent) } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }
    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
